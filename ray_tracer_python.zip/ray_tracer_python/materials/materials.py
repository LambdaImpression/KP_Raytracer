from ..color import Color


class Material:
    """This class has the material properties"""
    def __init__(self, color=Color.from_hex("#FFFFFF"),
                 ambient=0.05,
                 diffuse=1.0,
                 specular=1.0,
                 reflection=0.5):
        self.__color = color
        self.__ambient = ambient
        self.__diffuse = diffuse
        self.__specular = specular
        self.__reflection = reflection

    def color_at(self, position):
        return self.__color

    @property
    def ambient(self):
        return self.__ambient

    @property
    def diffuse(self):
        return self.__diffuse

    @property
    def specular(self):
        return self.__specular

    @property
    def reflection(self):
        return self.__reflection


class ChessMaterial:
    """This class has the chess_material properties"""
    def __init__(self, first_color=Color.from_hex("#FFFFFF"),
                 second_color=Color.from_hex("#000000"),
                 ambient=0.05, diffuse=1.0, specular=1.0, reflection=0.5):
        self.__first_color = first_color
        self.__second_color = second_color
        self.__ambient = ambient
        self.__diffuse = diffuse
        self.__specular = specular
        self.__reflection = reflection

    def color_at(self, position):
        if int((position.x + 5.0) * 3.0) % 2 == int(position.z * 3.0) % 2:
            return self.__first_color
        else:
            return self.__second_color

    @property
    def ambient(self):
        return self.__ambient

    @property
    def diffuse(self):
        return self.__diffuse

    @property
    def specular(self):
        return self.__specular

    @property
    def reflection(self):
        return self.__reflection