# This script was only used to create a plot,
# it is therefore not included in the actual
# implementations

import matplotlib.pyplot as plt
import numpy as np

x = np.array([2.0, 4.0, 6.0, 8.0])

y_py = np.array([
    62.26583170890808,
    26.61482286453247,
    17.824358224868774,
    14.02276611328125
    ])
y_go = np.array([
    111.979274,
    49.321261,
    46.317061,
    40.200679
    ])
plt.plot(x, y_py, label="Python")
plt.plot(x, y_go, label="Golang")
plt.grid(axis='y')
plt.legend(loc="upper right")

plt.title("Performance comparison Python and Golang")
plt.xlabel("Used cores/goroutines")
plt.ylabel("Processing time in seconds")

plt.show()