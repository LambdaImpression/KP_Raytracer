from time import time
from datetime import datetime
from multiprocessing import Value, Process, Pipe, current_process
from image import Image
from objects.ray import Ray
from objects.point import Point
from color import Color
import progress
from PIL import Image as pili
import cv2

MAX_DEPTH = 2
MIN_DISPLACE = 0.0001


def convert_and_show_PPM(image_file_name):
    cv2.imwrite(image_file_name + ".png", cv2.imread(image_file_name + ".ppm"))
    with pili.open(image_file_name + '.png') as png:
        png.show()


class RenderEngine:
    """The engine to render objects
    with ray tracing"""

    def __init__(self, processes):
        self.__processes = processes

    def multiprocess_rendering(self, scene, processes, image_file_name):
        def split_image_into_parts(rows, parts):
            divider, rest = divmod(rows, parts)
            return [(i * divider + min(i, rest), (i + 1) * divider + min(i + 1, rest)) for i in range(parts)]

        width = scene.width
        height = scene.height
        process_list = []
        total = height * 2
        try:
            current_time_start = datetime.now().strftime("%H:%M:%S")
            t1_start = time()
            image_parts = processes - 1 if processes > 1 else processes
            ranges = split_image_into_parts(height, image_parts)
            shared_rows = Value("i", 0)
            if processes > 1:
                order = Value("i", 0)
                pipe, pipe2 = Pipe()
                pos = 0
                for height_min, height_max in ranges:
                    process_list.append(
                        Process(
                            target=self.render,
                            args=(
                                scene, height_min, height_max,
                                shared_rows, total, pos, order, pipe)
                        )
                    )
                    pos += 1
                for p in process_list:
                    p.start()
                process_list.append(
                    Process(
                        target=self.build_image_from_pipe,
                        args=(pipe2, height, width, image_file_name, processes)
                    )
                )
                process_list[-1].start()
                for p in process_list:
                    p.join()
                t1_stop = time()
                current_time_stop = datetime.now().strftime("%H:%M:%S")
            else:
                current_time_start = datetime.now().strftime("%H:%M:%S")
                t1_start = time()
                text = self.render(scene, 0, height, shared_rows, total)
                self.build_image_single_core(height, width, image_file_name, text)
                t1_stop = time()
                current_time_stop = datetime.now().strftime("%H:%M:%S")
            print("\n")
            print(f"Time start: {current_time_start}")
            print(f"Time end: {current_time_stop}")
            print(f"Elapsed time during the whole program in seconds: {t1_stop - t1_start}")
            print(f"Elapsed time during the whole program in minutes: {(t1_stop - t1_start)/60}")
            convert_and_show_PPM(image_file_name)
        except Exception as e:
            print(e)

    def build_image_single_core(self, height, width, image_file_name, text):
        with open(f"{image_file_name}.ppm", "w") as image_fileobject:
            Image.create_ppm_header(image_fileobject, height=height, width=width)
            image_fileobject.write(text)

    def build_image_from_pipe(self, pipe2, height, width, image_file_name, processes):
        with open(f"{image_file_name}.ppm", "w") as image_fileobject:
            count = 0
            Image.create_ppm_header(image_fileobject, height=height, width=width)
            while True:
                item = pipe2.recv()
                if item is not None:
                    image_fileobject.write(item)
                else:
                    count += 1
                    if count == processes - 1:
                        break

    def render(self, scene, height_min, height_max, shared_rows, total, pos=0, order=None, pipe=None):
        width = scene.width
        height = scene.height
        aspect_ratio = float(width) / height
        x0 = -1.0
        x1 = +1.0
        xstep = (x1 - x0) / (width - 1)
        y0 = -1.0 / aspect_ratio
        y1 = +1.0 / aspect_ratio
        ystep = (y1 - y0) / (height - 1)
        camera = scene.camera
        pixels = Image(width, height_max - height_min)
        for j in range(height_min, height_max):
            y = y0 + j * ystep
            for i in range(width):
                x = x0 + i * xstep
                ray = Ray(camera, Point(x, y) - camera)
                pixels.set_pixel_color(i, j - height_min, self.trace_ray(ray, scene))
            if shared_rows:
                with shared_rows.get_lock():
                    shared_rows.value += 1
                    progress.progress(shared_rows.value,
                                      total,
                                      prefix="Generating picture parts")

        picture_string = pixels.create_ppm_body(shared_rows, total)
        if pipe is not None:
            while order.value != pos:
                pass

            pipe.send(picture_string)
            pipe.send(None)
            order.value += 1
        else:
            return picture_string

    def trace_ray(self, ray, scene, depth=0):
        color = Color(0, 0, 0)
        distance_hit, object_hit = self.find_nearest_object(ray, scene)
        if object_hit is None:
            return color
        hit_position = ray.origin + ray.direction * distance_hit
        hit_normal = object_hit.normal(hit_position)
        color += self.color_at(object_hit, hit_position, hit_normal, scene)
        if depth < MAX_DEPTH:
            # reflection with ray-attenuation
            color += self.trace_ray(
                Ray(
                    hit_position + hit_normal * MIN_DISPLACE,
                    ray.direction - 2 * ray.direction.dot_product(hit_normal) * hit_normal
                ),
                scene,
                depth + 1
            ) * object_hit.material.reflection
        return color

    def find_nearest_object(self, ray, scene):
        min_distance = None
        object_hit = None
        for obj in scene.objects:
            distance = obj.intersects(ray)
            if distance is not None and (object_hit is None or distance < min_distance):
                min_distance = distance
                object_hit = obj
        return min_distance, object_hit

    def color_at(self, object_hit, hit_position, normal, scene):
        material = object_hit.material
        object_color = material.color_at(hit_position)
        to_camera = scene.camera - hit_position
        specular_exp = 50
        color = material.ambient * Color.from_hex("#FFFFFF")
        for light in scene.lights:
            # Calculations of Lambert-shading (diffuse)
            to_light = Ray(hit_position, light.position - hit_position)
            color += (object_color * material.diffuse * max(normal.dot_product(to_light.direction), 0))

            # Calculations of Blinn-Phong-shading (specular)
            vector_in_halve = (to_light.direction + to_camera).normalize()
            color += (light.color * material.specular * max(normal.dot_product(vector_in_halve), 0) ** specular_exp)
        return color
