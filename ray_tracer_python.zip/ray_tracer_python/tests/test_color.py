import unittest
from ray_tracer_python.color import Color


class TestColor(unittest.TestCase):
    def setUp(self) -> None:
        self.c1 = Color()

    def test_from_hex(self):
        self.c1 = self.c1.from_hex("#AC00E6")
        self.assertEqual(self.c1.x * 255, 172)
        self.assertEqual(self.c1.y * 255, 0)
        self.assertEqual(self.c1.z * 255, 230)


if __name__ == "__main__":
    unittest.main()