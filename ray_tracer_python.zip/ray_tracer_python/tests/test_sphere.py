import unittest
from ray_tracer_python.color import Color
from ray_tracer_python.materials.materials import Material
from ray_tracer_python.objects.point import Point
from ray_tracer_python.objects.ray import Ray
from ray_tracer_python.objects.vector import Vector
from ..objects.sphere import Sphere


class TestSphere(unittest.TestCase):
    def setUp(self) -> None:
        self.c1 = Vector(0, -.35, -1)
        self.s1 = Sphere(Point(0.0, -0.1, 1), .6, Material(Color.from_hex("#1E81B0")))
        self.r1 = Ray(self.c1, Point(0, -.35) - self.c1)

    def test_intersects(self):
        self.assertEqual(self.s1.intersects(self.r1), 1.4545643942682145)

    def test_normal(self):
        self.assertEqual(self.s1.normal(Point(0.1, -0.2, 2)).x, 0.09901475429766743)
        self.assertEqual(self.s1.normal(Point(0.1, -0.2, 2)).y, -0.09901475429766743)
        self.assertEqual(self.s1.normal(Point(0.1, -0.2, 2)).z, 0.9901475429766743)


if __name__ == "__main__":
    unittest.main()