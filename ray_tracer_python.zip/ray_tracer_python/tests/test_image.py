import unittest
from ray_tracer_python.image import Image


class TestImage(unittest.TestCase):
    def setUp(self) -> None:
        self.i1 = Image(4, 4)

    def test_set_pixel_color(self):
        self.i1.set_pixel_color(2, 2, 999)
        self.assertEqual(self.i1.pixels[2][2], 999)
        self.assertEqual(self.i1.pixels[1][1], None)


if __name__ == "__main__":
    unittest.main()