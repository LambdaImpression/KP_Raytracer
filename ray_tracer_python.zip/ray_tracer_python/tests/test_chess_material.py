import unittest
from ray_tracer_python.materials.materials import ChessMaterial
from ray_tracer_python.objects.vector import Vector


class TestChessMaterial(unittest.TestCase):
    def setUp(self) -> None:
        self.c1 = ChessMaterial()

    def test_color_at(self):
       self.assertEqual(self.c1.color_at(Vector(2, 1, 1)).x * 255, 255)


if __name__ == "__main__":
    unittest.main()