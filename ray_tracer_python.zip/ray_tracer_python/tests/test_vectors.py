import unittest
from ..objects.vector import Vector


class TestVectors(unittest.TestCase):
    def setUp(self) -> None:
        self.__v1 = Vector(1.0, -2.0, -2.0)
        self.__v2 = Vector(3.0, 6.0, 9.0)

    def test_dot_product(self):
        self.assertEqual(self.__v1.dot_product(self.__v2), -27)

    def test_magnitude(self):
        self.assertEqual(self.__v1.magnitude(), 3.0)

    def test_normalize(self):
        self.assertEqual(self.__v1.normalize().x, 0.3333333333333333)

    def test_addition(self):
        sum = self.__v1 + self.__v2
        self.assertEqual(getattr(sum, 'x'), 4.0)
        self.assertEqual(getattr(sum, 'y'), 4.0)
        self.assertEqual(getattr(sum, 'z'), 7.0)

    def test_subtraction(self):
        sum = self.__v1 - self.__v2
        self.assertEqual(getattr(sum, 'x'), -2.0)
        self.assertEqual(getattr(sum, 'y'), -8.0)
        self.assertEqual(getattr(sum, 'z'), -11.0)

    def test_multiplication(self):
        mul = self.__v1 * 3
        self.assertEqual(getattr(mul, 'x'), 3.0)
        self.assertEqual(getattr(mul, 'y'), -6.0)
        self.assertEqual(getattr(mul, 'z'), -6.0)

    def test_division(self):
        mul = self.__v1 / 2
        self.assertEqual(getattr(mul, 'x'), 0.5)
        self.assertEqual(getattr(mul, 'y'), -1.0)
        self.assertEqual(getattr(mul, 'z'), -1.0)


if __name__ == "__main__":
    unittest.main()