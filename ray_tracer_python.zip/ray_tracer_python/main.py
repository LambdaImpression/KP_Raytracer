#!/usr/bin/env python
"""Python Raytracer
    Author: Philipp Ulrich"""
import argparse
import importlib
import sys
import os
from multiprocessing import cpu_count
from objects.scene import Scene
from engine.render_engine import RenderEngine


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-s",
                        "--scene",
                        action="store",
                        type=str,
                        dest="scene",
                        default="spheres_chessground",
                        help="Give a scene.py file, which gives the 2D scene, located in the scenes folder "
                             "and should be processed by the ray tracer")
    parser.add_argument("-f",
                        "--filepath",
                        action="store",
                        type=str,
                        default="created_images\\default",
                        dest="filepath",
                        help="The filepath where the created images will be saved")
    parser.add_argument("-p",
                        "--processes",
                        action="store",
                        type=int,
                        dest="processes",
                        default=0,
                        help="Number of processes for parallelism (0 or default = automatic config)")
    parser.add_argument("-wi",
                        "--width",
                        action="store",
                        type=int,
                        dest="width",
                        default=320,
                        help="Width of the processed image")
    parser.add_argument("-hi",
                        "--height",
                        action="store",
                        type=int,
                        dest="height",
                        default=200,
                        help="Height of the processed image")
    args = parser.parse_args()
    cwd = os.getcwd()
    sys.path.append(cwd)
    sys.path.append(cwd.replace("\\ray_tracer_python", ""))
    args.scene = args.scene.replace(".py", "")
    if args.processes == 0 or args.processes > cpu_count():
        args.processes = cpu_count()

    if args.scene[-1:-3] == '.py':
        args.scene += args.scene[:-2]

    print(f"*=" * 100)
    print(f"\nUsing {args.processes} cores for processing")
    print(f"Creating image with: \n"
          f"    width: {args.width} \n"
          f"    height: {args.height}")
    print(f"Importing module {args.scene}...")
    try:
        module = importlib.import_module(f"ray_tracer_python.scenes.{args.scene}", package=None)
        print(f"Module imported succesfully!")
        print("Rendering image... ")
        scene = Scene(module.CAMERA,
                      module.OBJECTS,
                      module.LIGHTS,
                      args.width,
                      args.height)
        engine = RenderEngine(args.processes)
        engine.multiprocess_rendering(scene, args.processes, args.filepath)
    except Exception as e:
        print(e)


if __name__ == "__main__":
    main()
