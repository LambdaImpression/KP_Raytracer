import progress


class Image:
    """Class for Images"""

    def __init__(self, width, height):
        self.__width = width
        self.__height = height
        self.__pixels = [[None for _ in range(self.__width)] for _ in range(self.__height)]

    def set_pixel_color(self, x, y, color):
        self.pixels[y][x] = color

    @staticmethod
    def create_ppm_header(image_fileobject, height=None, width=None):
        """Write the header of a ppm file"""
        image_fileobject.write(f"P3 {width} {height}\n255\n")

    def create_ppm_body(self, shared_rows, total):
        def to_byte(x):
            return round(max(min(x * 255, 255), 0))

        text = ""
        for row in self.pixels:
            for color in row:
                text += f"{to_byte(color.x)} {to_byte(color.y)} {to_byte(color.z)} "
            text += "\n"
            if shared_rows:
                with shared_rows.get_lock():
                    shared_rows.value += 1
                    progress.progress(shared_rows.value,
                                      total,
                                      prefix="Generating picture parts")
        return text

    @property
    def width(self):
        return self.__width

    @width.setter
    def width(self, width):
        self.__width = width

    @property
    def height(self):
        return self.__height

    @height.setter
    def height(self, height):
        self.__height = height

    @property
    def pixels(self):
        return self.__pixels

    @pixels.setter
    def pixels(self, pixels):
        self.__pixels = pixels
