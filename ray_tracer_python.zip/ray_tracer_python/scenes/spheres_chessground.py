from ..objects.sphere import Sphere
from ..objects.vector import Vector
from ..objects.light import Light
from ..objects.point import Point
from ..materials.materials import Material, ChessMaterial
from ..color import Color

CAMERA = Vector(0, -.35, -1)
OBJECTS = [
    Sphere(Point(0, 10000.5, 1), 10000.0,
           ChessMaterial(
               first_color=Color.from_hex("#000000"),
               second_color=Color.from_hex("#FFFFFF"),
               ambient=0.2,
               reflection=0.2)
           ),
    # blue sphere
    Sphere(Point(0.0, -0.1, 1), .6, Material(Color.from_hex("#1E81B0"))),
    # pink sphere
    Sphere(Point(-1.75, -0.1, 2.25), .4, Material(Color.from_hex("#803980"))),
    # schwarze sphere
    Sphere(Point(.75, -.5, 1), .4, Material(Color.from_hex("#FFFFFFF"))),
    # #42f57e
    Sphere(Point(1.30, -.8, 1), .4, Material(Color.from_hex("#42f57e"))),
]
LIGHTS = [
    Light(Point(1.5, -.5, -10), Color.from_hex("#FFFFFF")),
    Light(Point(-.5, -10.5, 0), Color.from_hex("#FFFFFF"))
]
