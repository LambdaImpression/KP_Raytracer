import math
import sys


def progress(count, total, status='', prefix=''):
    bar_len = 60
    filled_len = int(round(bar_len * count / float(total)))

    percents = math.floor(100.0 * count / float(total))
    bar = '=' * filled_len + '-' * (bar_len - filled_len)

    sys.stdout.write('\r%s [%s] %s%s %s' % (prefix, bar, percents, '%', status))
    sys.stdout.flush()
