from objects.vector import Vector


class Color(Vector):
    """Class to store colors in RGB"""
    @classmethod
    def from_hex(cls, hexcolor="#000000"):
        return cls(
            int(hexcolor[1:3], 16) / 255.0,
            int(hexcolor[3:5], 16) / 255.0,
            int(hexcolor[5:7], 16) / 255.0
        )
