from objects.vector import Vector


class Point(Vector):
    """A class for points in 3D space"""
    pass
