class Ray:
    """The Ray. It has origin and the
    normalized direction"""
    def __init__(self, origin, direction):
        self.__origin = origin
        self.__direction = direction.normalize()

    @property
    def origin(self):
        return self.__origin

    @origin.setter
    def origin(self, origin):
        self.__origin = origin

    @property
    def direction(self):
        return self.__direction

    @direction.setter
    def direction(self, direction):
        self.__direction = direction