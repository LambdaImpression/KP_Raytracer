from ..color import Color


class Light:
    """This class represents
    the lightsource"""

    def __init__(self, position, color=Color.from_hex("#FFFFFF")):
        self.__position = position
        self.__color = color

    @property
    def position(self):
        return self.__position

    @property
    def color(self):
        return self.__color
