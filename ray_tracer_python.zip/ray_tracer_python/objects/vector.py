import math


class Vector:
    """A multipurpose three element vector
        for 3D applications"""

    def __init__(self, x=0.0, y=0.0, z=0.0):
        self.__x: float = x
        self.__y: float = y
        self.__z: float = z

    def dot_product(self, other):
        return self.__x * other.__x + self.__y * other.__y + self.__z * other.__z

    def magnitude(self):
        return math.sqrt(self.dot_product(self))

    def normalize(self):
        return self / self.magnitude()

    def __add__(self, other):
        return Vector(self.__x + other.__x,
                      self.__y + other.__y,
                      self.__z + other.__z)

    def __sub__(self, other):
        return Vector(self.__x - other.__x,
                      self.__y - other.__y,
                      self.__z - other.__z)

    def __mul__(self, other):
        assert not isinstance(other, Vector)
        return Vector(self.__x * other,
                      self.__y * other,
                      self.__z * other)

    def __rmul__(self, other):
        return self.__mul__(other)

    def __truediv__(self, other):
        assert not isinstance(other, Vector)
        return Vector(self.__x / other,
                      self.__y / other,
                      self.__z / other)

    @property
    def x(self):
        return self.__x

    @x.setter
    def x(self, x):
        self.__x = x

    @property
    def y(self):
        return self.__y

    @y.setter
    def y(self, y):
        self.__y = y

    @property
    def z(self):
        return self.__z

    @z.setter
    def z(self, z):
        self.__z = z

