import math


class Sphere:
    """A Sphere as a 3D shape with center,
    radius and material"""

    def __init__(self, center, radius, material):
        self.__center = center
        self.__radius = radius
        self.__material = material

    def intersects(self, ray):
        """Function to check for intersection
        of the ray with the sphere"""
        sphere_to_ray = ray.origin - self.__center
        b = 2 * ray.direction.dot_product(sphere_to_ray)
        c = sphere_to_ray.dot_product(sphere_to_ray) - self.__radius * self.__radius
        discriminant = math.pow(b, 2) - 4 * c

        if discriminant >= 0:
            distance = (-b - math.sqrt(discriminant)) / 2
            if distance > 0:
                return distance

    def normal(self, point_on_surface):
        """Function to get the
        normal of the surface"""
        return (point_on_surface - self.__center).normalize()

    @property
    def center(self):
        return self.__center

    @property
    def radius(self):
        return self.__radius

    @property
    def material(self):
        return self.__material
