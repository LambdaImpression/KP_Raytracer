class Scene:
    """The overall scene, which holds all
    the information needed for the rendering engine"""
    def __init__(self, camera, objects, lights, width, height):
        self.__camera = camera
        self.__objects = objects
        self.__lights = lights
        self.__width = width
        self.__height = height

    @property
    def camera(self):
        return self.__camera

    @property
    def objects(self):
        return self.__objects

    @property
    def lights(self):
        return self.__lights

    @property
    def width(self):
        return self.__width

    @property
    def height(self):
        return self.__height
