package main

import (
	"ray_tracer_go/objects"
	"testing"
)

func TestFromHex(t *testing.T) {
	var actual, err = objects.Color{}.FromHex("#AC00E6")
	if err != nil {
		panic(err)
	}
	var expected = objects.Vector{
		X: 172,
		Y: 0,
		Z: 230,
	}
	if actual.X != expected.X && actual.Y != expected.Y && actual.Z != expected.Z {
		t.Errorf("Expected value %f %f %f is not same as actual %f %f %f",
			expected.X, expected.Y, expected.Z, actual.X, actual.Y, actual.Z)
	}
}
