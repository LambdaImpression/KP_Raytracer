#!/usr/bin/env python
import argparse
from PIL import Image as pili
import cv2


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-f",
                        "--filepath",
                        action="store",
                        type=str,
                        dest="filepath")
    args = parser.parse_args()
    filepath = args.filepath.replace(".ppm", "")
    cv2.imwrite(args.filepath + ".png", cv2.imread(filepath + ".ppm"))
    with pili.open(args.filepath + '.png') as png:
        png.show()

