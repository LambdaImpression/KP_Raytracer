package main

import (
	"ray_tracer_go/objects"
	"testing"
)

func TestColorAt(t *testing.T) {
	var i1 = objects.NewImage(4, 4)
	var color, err = objects.Color{}.FromHex("#FFFFFF")
	if err != nil {
		panic(err)
	}
	i1.SetPixel(2, 2, color)
	var actual = i1.Pixels[2][2].X * 255
	var expected = 255.0
	if actual != expected {
		t.Errorf("Expected value %f is not same as"+
			" actual %f", expected, actual)
	}
}
