package main

import (
	"ray_tracer_go/objects"
	"testing"
)

func TestIntersects(t *testing.T) {
	var color, err = objects.Color{}.FromHex("#1E81B0")
	if err != nil {
		panic(err)
	}
	var s1 = objects.Sphere{
		Center: &objects.Vector{
			X: 0.0,
			Y: -0.1,
			Z: 1.0,
		},
		Radius: .6,
		Material: objects.Material{
			Color: color,
			Type:  "standard",
		},
	}
	var r1 = objects.Ray{
		Origin:    objects.Vector{X: 0, Y: -0.35, Z: -1.0},
		Direction: objects.Vector{X: 0, Y: -0.35, Z: 0}.Sub(objects.Vector{X: 0, Y: -0.35, Z: -1.0}).Normalize(),
	}
	actual := s1.Intersects(r1)
	expected := 1.4545643942682145
	if actual != expected {
		t.Errorf("Expected value %f is not same as"+
			" actual %f", expected, actual)
	}
}

func TestNormal(t *testing.T) {
	var color, err = objects.Color{}.FromHex("#1E81B0")
	if err != nil {
		panic(err)
	}
	var s1 = objects.Sphere{
		Center: &objects.Vector{
			X: 0.0,
			Y: -0.1,
			Z: 1.0,
		},
		Radius: .6,
		Material: objects.Material{
			Color: color,
			Type:  "standard",
		},
	}
	actual := s1.Normal(objects.Vector{
		X: 0.1,
		Y: -0.2,
		Z: 2.0,
	})
	expected := objects.Vector{
		X: 0.09901475429766743,
		Y: -0.09901475429766743,
		Z: 0.9901475429766743,
	}
	if actual.X != expected.X && actual.Y != expected.Y && actual.Z != expected.Z {
		t.Errorf("Expected value %f is not same as"+
			" actual %f", expected, actual)
	}
}
