package main

import (
	"encoding/json"
	"flag"
	"os"
	"ray_tracer_go/objects"
	"runtime"
)

type SceneConfig struct {
	Camera  objects.Vector    `json:"Camera"`
	Objects *[]objects.Sphere `json:"Objects"`
	Lights  []objects.Light   `json:"Lights"`
}

func init() {}

func main() {
	var saveDir = flag.String("d", "\\created_images\\default.ppm",
		"Path to save file to e.g. C:\\Users\\image_name")
	var scene = flag.String("s", "spheres_chessground.json",
		"Give a scene.py file, which gives the 2D scene which should be processed by the ray tracer")
	var processes = flag.Int("p", runtime.NumCPU(),
		"Number of processes for parallelism")
	var routines = flag.Int("r", 4,
		"Number of goroutines for parallelism")
	var width = flag.Int("wi", 320, "Width of the processed image")
	var height = flag.Int("hi", 200, "Height of the processed image")
	flag.Parse()
	if *processes == 0 || *processes > runtime.NumCPU() {
		*processes = runtime.NumCPU()
		runtime.GOMAXPROCS(runtime.NumCPU())
	} else {
		runtime.GOMAXPROCS(*processes)
	}
	var str1 = *scene
	if string(str1[len(str1)-5:]) != ".json" {
		str1 = str1 + ".json"
	}
	var str2 = *saveDir
	if len(str2) < 2 {
		panic("Filename must be atleast two characters long!")
	}
	if len(str2) > 4 {
		if string(str2[len(str2)-4:]) != ".ppm" {
			str2 = str2 + ".ppm"
		}
	}
	var jsonBytes, err = os.ReadFile("scenes/" + str1)
	if err != nil {
		panic(err)
	}

	var sceneConfig SceneConfig
	var unmarshalErr = json.Unmarshal(jsonBytes, &sceneConfig)
	if unmarshalErr != nil {
		panic(unmarshalErr)
	}

	var sce = objects.Scene{
		Camera:  sceneConfig.Camera,
		Objects: *sceneConfig.Objects,
		Lights:  sceneConfig.Lights,
		Width:   *width,
		Height:  *height,
	}

	engine := objects.RenderEngine{
		Scene:      sce,
		FileName:   *saveDir,
		Goroutines: *routines,
		Processes:  *processes,
	}
	engine.Run()
}
