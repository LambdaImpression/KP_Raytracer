package objects

import (
	"math"
)

type Vector struct {
	X float64
	Y float64
	Z float64
}

func (v Vector) DotProduct(ov Vector) float64 {
	return v.X*ov.X + v.Y*ov.Y + v.Z*ov.Z
}

func (v Vector) Magnitude() float64 {
	return math.Sqrt(v.DotProduct(v))
}

func (v Vector) Normalize() Vector {
	return Vector{
		v.X / v.Magnitude(),
		v.Y / v.Magnitude(),
		v.Z / v.Magnitude(),
	}
}

func (v Vector) Add(ov Vector) Vector {
	return Vector{v.X + ov.X, v.Y + ov.Y, v.Z + ov.Z}
}

func (v Vector) Sub(ov Vector) Vector {
	return Vector{v.X - ov.X, v.Y - ov.Y, v.Z - ov.Z}
}

func (v Vector) Mul(m float64) Vector {
	return Vector{m * v.X, m * v.Y, m * v.Z}
}

func (v Vector) Div(d float64) Vector {
	return Vector{v.X / d, v.Y / d, v.Z / d}
}
