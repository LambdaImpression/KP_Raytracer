package objects

import (
	"github.com/gosuri/uiprogress"
	math "math"
	"os"
	"runtime"
	"strconv"
)

type Image struct {
	Width  int
	Height int
	Pixels [][]Color
}

func NewImage(width, height int) Image {
	var initSlice = func() [][]Color {
		var slice = make([][]Color, height)
		for innerslice := range slice {
			slice[innerslice] = make([]Color, width)
		}
		return slice
	}
	return Image{Width: width, Height: height, Pixels: initSlice()}
}

func (i *Image) SetPixel(column, row int, color Color) {
	i.Pixels[row][column] = color
}

func ToByte(c float64) int {
	return int(math.Round(math.Max(math.Min(c*255, 255), 0)))
}

func (i Image) CreatePPMHeader(fileName string, width, height int) {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	var text = "P3 " + strconv.Itoa(width) + " " + strconv.Itoa(height) + "\n255\n"
	WriteToFile(fileName, text)
}

func (i Image) CreatePPMBody(bar *uiprogress.Bar) string {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	var text string
	for _, row := range i.Pixels {
		for _, color := range row {
			text = text + strconv.Itoa(ToByte(color.X)) + " " + strconv.Itoa(ToByte(color.Y)) + " " + strconv.Itoa(ToByte(color.Z)) + " "
		}
		text = text + "\n"
		bar.Incr()
	}
	return text
}

func WriteToFile(fileName, text string) {
	var file, errFileOpen = os.OpenFile(fileName, os.O_APPEND|os.O_WRONLY|os.O_CREATE, 0600)
	if errFileOpen != nil {
		return
	}

	var _, errWriteFile = file.WriteString(text)
	if errWriteFile != nil {
		return
	}

	errFileClose := file.Close()
	if errFileClose != nil {
		return
	}
}
