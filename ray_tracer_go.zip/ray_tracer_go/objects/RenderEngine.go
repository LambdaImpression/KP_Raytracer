package objects

import (
	"fmt"
	"github.com/gosuri/uiprogress"
	_ "github.com/shirou/gopsutil/v3/cpu"
	"math"
	"os"
	"os/exec"
	"runtime"
	"sync"
	"time"
)

const MAX_DEPTH int = 2
const DELTA = 0.0001

type RenderEngine struct {
	IntChan    chan int
	Scene      Scene
	FileName   string
	Goroutines int
	Processes  int
}

func (r *RenderEngine) Run() {

	//vars
	var imageParts = r.SeparateImage(r.Scene.Height, r.Goroutines)

	//synchro
	var wg sync.WaitGroup

	//channels
	var sarr = make(chan []string, 1)
	var arr = make([]string, len(imageParts))
	sarr <- arr
	//start the rendering processes
	uiprogress.Start()
	start := time.Now()
	for index, part := range imageParts {
		wg.Add(1)
		go r.Render(part, index, sarr, &wg)
	}
	time.Sleep(time.Second)
	wg.Wait()
	stop := time.Now()
	duration := time.Since(start)
	uiprogress.Stop()
	fmt.Printf("Used %d cores for processing\n", r.Processes)
	fmt.Printf("Used %d goroutines for processing\n", r.Goroutines)
	fmt.Printf("Created image with:\n")
	fmt.Printf("		Image width: %d\n", r.Scene.Width)
	fmt.Printf("		Image height: %d\n", r.Scene.Height)
	fmt.Printf("Time start: " + start.Format(time.Kitchen) + "\n")
	fmt.Printf("Time end: " + stop.Format(time.Kitchen) + "\n")
	fmt.Printf("Elapsed time during the whole program in seconds: %f\n", duration.Seconds())
	fmt.Printf("Elapsed time during the whole program in minutes: %f\n", duration.Seconds()/60)
	Image{}.CreatePPMHeader(r.FileName, r.Scene.Width, r.Scene.Height)
	WriteToFile(r.FileName, r.SpliceToString(sarr))
	var wd, _ = os.Getwd()
	if string(r.FileName[len(r.FileName)-4:]) == ".ppm" {
		r.FileName = r.FileName[:len(r.FileName)-4]
	}
	if string(r.FileName[1]) == "\\" {
		r.FileName = r.FileName[2:]
	}
	var com = "python"
	cmd := exec.Command(com, "..\\ray_tracer_go\\conversion_with_python.py", "-f"+wd+"\\"+r.FileName)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	comRunError := cmd.Run()
	if comRunError != nil {
		panic(comRunError)
	}
}

func (r *RenderEngine) Render(
	imageArea []int,
	index int,
	sarr chan []string,
	wg *sync.WaitGroup,
) {
	runtime.LockOSThread()
	defer wg.Done()
	var width = r.Scene.Width
	var height = r.Scene.Height
	var max = (imageArea[1] - imageArea[0]) * 2
	var bar = uiprogress.AddBar(max).AppendCompleted().PrependElapsed()
	var aspectRatio = float64(width) / float64(height)
	var x0 = -1.0
	var x1 = 1.0
	var xStep = (x1 - x0) / (float64(width) - 1)
	var y0 = float64(-1.0) / float64(aspectRatio)
	var y1 = 1.0 / float64(aspectRatio)
	var yStep = (y1 - y0) / (float64(height) - 1)

	var camera = r.Scene.Camera
	var ima = NewImage(width, imageArea[1]-imageArea[0])
	for j := imageArea[0]; j < imageArea[1]; j++ {
		var jFloat = float64(j)
		var y = y0 + jFloat*yStep
		for i := 0; i < width; i++ {
			var iFloat = float64(i)
			var x = x0 + iFloat*xStep
			var ray = Ray{Origin: camera, Direction: Point{Vector: Vector{X: x, Y: y}}.Vector.Sub(camera).Normalize()}
			go ima.SetPixel(i, j-imageArea[0], r.RayTrace(ray, 0))
		}
		bar.Incr()
	}
	var text = ima.CreatePPMBody(bar)
	arr := <-sarr
	arr[index] = text
	sarr <- arr
	runtime.UnlockOSThread()
}

func (r *RenderEngine) SpliceToString(sarr <-chan []string) string {
	if len(sarr) > 1 {
		panic("Shared channel for creating string out of slice must have length 1")
	}
	var resultString = ""
	arr := <-sarr
	for _, a := range arr {
		resultString = resultString + a
	}
	return resultString
}

func (r *RenderEngine) SeparateImage(rows, parts int) [][]int {

	var DivMod = func(numerator, denominator int) (quotient, remainder int) {
		quotient = numerator / denominator
		remainder = numerator % denominator
		return
	}

	var divider, rest = DivMod(rows, parts)
	var outerSlice = make([][]int, parts)
	for i := 0; i < parts; i++ {
		var subSlice = []int{
			i*divider + int(math.Min(float64(i), float64(rest))),
			(i+1)*divider + int(math.Min(float64(i)+1, float64(rest))),
		}
		outerSlice[i] = subSlice
	}
	return outerSlice
}

func (r *RenderEngine) RayTrace(ray Ray, depth int) Color {
	var color = Color{Vector: Vector{X: 0, Y: 0, Z: 0}}
	var distanceHit, objectHit = r.FindNearest(ray)
	if objectHit == nil {
		return color
	}
	var hitPosition = ray.Origin.Add(ray.Direction.Mul(distanceHit))
	var hitNormal = objectHit.Normal(hitPosition)
	color = Color{Vector: color.Vector.Add(r.RenderColorAt(*objectHit, hitPosition, hitNormal))}
	if depth < MAX_DEPTH {
		var newRayPosition = hitPosition.Add(hitNormal.Mul(DELTA))
		var newRayDirection = ray.Direction.Sub(hitNormal.Mul(2.0 * ray.Direction.DotProduct(hitNormal)))
		var newRay = Ray{Origin: newRayPosition, Direction: newRayDirection.Normalize()}
		//Attenuation
		color = Color{Vector: color.Vector.Add(r.RayTrace(newRay, depth+1).Mul(objectHit.Material.Reflection))}
	}
	return color
}

func (r *RenderEngine) FindNearest(ray Ray) (float64, *Sphere) {
	var distMin float64
	var objectHit *Sphere
	for objectIndex := 0; objectIndex < len(r.Scene.Objects); objectIndex++ {
		var distance = r.Scene.Objects[objectIndex].Intersects(ray)
		if distance != -9999.9999 && (objectHit == nil || distance < distMin) {
			distMin = distance
			objectHit = &r.Scene.Objects[objectIndex]
		}
	}
	return distMin, objectHit
}

func (r *RenderEngine) RenderColorAt(
	objectHit Sphere,
	hitPosition Vector,
	hitNormal Vector) Vector {

	var material = objectHit.Material
	var objectColor = material.MaterialColorAt(hitPosition)
	var toCam = r.Scene.Camera.Sub(hitPosition)
	var kSpecular = 50.0
	var value1, _ = Color{}.FromHex("#FFFFFF")
	var lightingColor = value1.Mul(material.Ambient)
	for _, light := range r.Scene.Lights {
		var toLight = Ray{
			Origin:    hitPosition,
			Direction: light.Position.Sub(hitPosition).Normalize(),
		}
		//Lambert shading (diffuse)
		lightingColor = lightingColor.Add(objectColor.Mul(material.Diffuse).Mul(math.Max(hitNormal.DotProduct(toLight.Direction), 0)))
		//Blinn-Phong shading (specular)
		var vectorOfHalve = (toLight.Direction.Add(toCam)).Normalize()
		lightingColor = lightingColor.Add(light.Color.Mul(material.Specular).Mul(math.Pow(math.Max(hitNormal.DotProduct(vectorOfHalve), 0), kSpecular)))
	}
	return lightingColor
}
