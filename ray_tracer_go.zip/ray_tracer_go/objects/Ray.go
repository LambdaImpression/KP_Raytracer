package objects

type Ray struct {
	Origin    Vector
	Direction Vector
}
