package objects

import (
	"errors"
	"strconv"
)

type Color struct {
	Vector
}

func (c Color) FromHex(hexColor string) (Color, error) {
	if len(hexColor) != 7 {
		return c, errors.New("hex color must be 7 characters")
	}
	if hexColor[0] != '#' {
		return c, errors.New("hex color must start with '#'")
	}
	var x, redError = strconv.ParseUint(hexColor[1:3], 16, 8)
	if redError != nil {
		return c, errors.New("red component invalid")
	}
	var y, greenError = strconv.ParseUint(hexColor[3:5], 16, 8)
	if greenError != nil {
		return c, errors.New("green component invalid")
	}
	var z, blueError = strconv.ParseUint(hexColor[5:7], 16, 8)
	if blueError != nil {
		return c, errors.New("blue component invalid")
	}
	return Color{Vector{X: float64(x) / 255, Y: float64(y) / 255, Z: float64(z) / 255}}, nil
}
