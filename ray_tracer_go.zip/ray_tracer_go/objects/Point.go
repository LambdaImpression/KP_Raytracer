package objects

type Point struct {
	Vector
}
