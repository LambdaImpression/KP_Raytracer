package objects

type Light struct {
	Position Point
	Color
}
