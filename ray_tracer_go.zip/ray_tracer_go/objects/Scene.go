package objects

type Scene struct {
	Camera  Vector
	Objects []Sphere
	Lights  []Light
	Width   int
	Height  int
}
