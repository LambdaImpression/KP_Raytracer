package objects

type Material struct {
	Color
	Ambient     float64
	Diffuse     float64
	Specular    float64
	Reflection  float64
	SecondColor Color
	Type        string
}

func (m Material) MaterialColorAt(position Vector) Color {
	switch m.Type {
	case "chess":
		if int((position.X+5.0)*3.0)%2 == int(position.Z*3.0)%2 {
			return m.Color
		} else {
			return m.SecondColor
		}
	case "standard":
		return m.Color
	default:
		return m.Color
	}
}
