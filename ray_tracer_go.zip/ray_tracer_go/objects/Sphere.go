package objects

import "math"

type Sphere struct {
	Center   *Vector
	Radius   float64
	Material Material
}

func (s Sphere) Intersects(ray Ray) float64 {
	ray.Direction = ray.Direction.Normalize()
	var sphereToRay = ray.Origin.Sub(*s.Center)
	var b = ray.Direction.Mul(2).DotProduct(sphereToRay)
	var c = sphereToRay.DotProduct(sphereToRay) - s.Radius*s.Radius
	var discriminant = b*b - 4*c
	var distance float64
	if discriminant >= 0 {
		distance = (-1*b - math.Sqrt(discriminant)) / 2
		if distance > 0 {
			return distance
		} else {
			return -9999.9999
		}
	}
	return -9999.9999
}

func (s Sphere) Normal(pointOnSurface Vector) Vector {
	return pointOnSurface.Sub(*s.Center).Normalize()
}
