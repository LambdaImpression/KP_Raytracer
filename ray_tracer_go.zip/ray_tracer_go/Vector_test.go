package main

import (
	"ray_tracer_go/objects"
	"testing"
)

func TestDotProduct(t *testing.T) {
	var v1 = objects.Vector{X: 1.0, Y: -2.0, Z: -2.0}
	var v2 = objects.Vector{X: 3.0, Y: 6.0, Z: 9.0}
	actual := v1.DotProduct(v2)
	expected := -27.0
	if actual != expected {
		t.Errorf("Expected value %f is not same as"+
			" actual %f", expected, actual)
	}
}

func TestMagnitude(t *testing.T) {
	var v1 = objects.Vector{X: 1.0, Y: -2.0, Z: -2.0}
	actual := v1.Magnitude()
	expected := 3.0
	if actual != expected {
		t.Errorf("Expected value %f is not same as"+
			" actual %f", expected, actual)
	}
}

func TestNormalize(t *testing.T) {
	var v1 = objects.Vector{X: 1.0, Y: -2.0, Z: -2.0}
	actual := v1.Normalize().X
	expected := 0.3333333333333333
	if actual != expected {
		t.Errorf("Expected value %f is not same as"+
			" actual %f", expected, actual)
	}
}

func TestAdd(t *testing.T) {
	var v1 = objects.Vector{X: 1.0, Y: -2.0, Z: -2.0}
	var v2 = objects.Vector{X: 3.0, Y: 6.0, Z: 9.0}
	actual := v1.Add(v2)
	expected := objects.Vector{X: 4.0, Y: 4.0, Z: 7.0}
	if actual.X != expected.X && actual.Y != expected.Y && actual.Z != expected.Z {
		t.Errorf("Expected value %f %f %f is not same as actual %f %f %f",
			expected.X, expected.Y, expected.Z, actual.X, actual.Y, actual.Z)
	}
}

func TestSub(t *testing.T) {
	var v1 = objects.Vector{X: 1.0, Y: -2.0, Z: -2.0}
	var v2 = objects.Vector{X: 3.0, Y: 6.0, Z: 9.0}
	actual := v1.Sub(v2)
	expected := objects.Vector{X: -2.0, Y: -8.0, Z: -11.0}
	if actual.X != expected.X && actual.Y != expected.Y && actual.Z != expected.Z {
		t.Errorf("Expected value %f %f %f is not same as actual %f %f %f",
			expected.X, expected.Y, expected.Z, actual.X, actual.Y, actual.Z)
	}
}

func TestMul(t *testing.T) {
	var v1 = objects.Vector{X: 1.0, Y: -2.0, Z: -2.0}
	var mul = 3.0
	actual := v1.Mul(mul)
	expected := objects.Vector{X: 3.0, Y: -6.0, Z: -6.0}
	if actual.X != expected.X && actual.Y != expected.Y && actual.Z != expected.Z {
		t.Errorf("Expected value %f %f %f is not same as actual %f %f %f",
			expected.X, expected.Y, expected.Z, actual.X, actual.Y, actual.Z)
	}
}

func TestDiv(t *testing.T) {
	var v1 = objects.Vector{X: 1.0, Y: -2.0, Z: -2.0}
	var mul = 3.0
	actual := v1.Div(mul)
	expected := objects.Vector{X: 0.3333333333333333, Y: -0.6666666666666667, Z: -0.6666666666666667}
	if actual.X != expected.X && actual.Y != expected.Y && actual.Z != expected.Z {
		t.Errorf("Expected value %f %f %f is not same as actual %f %f %f",
			expected.X, expected.Y, expected.Z, actual.X, actual.Y, actual.Z)
	}
}
