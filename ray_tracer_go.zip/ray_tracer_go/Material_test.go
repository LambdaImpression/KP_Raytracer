package main

import (
	"ray_tracer_go/objects"
	"testing"
)

func TestMaterialColorAt(t *testing.T) {
	var color1, err = objects.Color{}.FromHex("#FFFFFF")
	if err != nil {
		panic(err)
	}
	var color2, err2 = objects.Color{}.FromHex("#000000")
	if err2 != nil {
		panic(err2)
	}
	var m1 = objects.Material{
		Color:       color1,
		Ambient:     0.05,
		Diffuse:     1.0,
		Specular:    1.0,
		Reflection:  0.5,
		SecondColor: color2,
		Type:        "chess",
	}

	var v1 = objects.Vector{
		X: 2.0,
		Y: 1.0,
		Z: 1.0,
	}
	var actual = m1.MaterialColorAt(v1)
	var expected = objects.Vector{
		X: 255,
		Y: 255,
		Z: 255,
	}
	if actual.X*255 != expected.X && actual.Y*255 != expected.Y && actual.Z*255 != expected.Z {
		t.Errorf("Expected value %f %f %f is not same as actual %f %f %f",
			expected.X, expected.Y, expected.Z, actual.X, actual.Y, actual.Z)
	}
}
