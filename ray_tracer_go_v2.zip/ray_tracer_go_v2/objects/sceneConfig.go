package objects

type SceneConfig struct {
	Spheres []Sphere `json:"Spheres"`
}
