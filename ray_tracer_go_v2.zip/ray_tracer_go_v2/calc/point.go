package calc

// Point is an alias for Vec3.
type Point = Vec3
