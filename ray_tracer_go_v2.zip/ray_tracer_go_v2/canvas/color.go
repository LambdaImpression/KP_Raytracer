package canvas

import (
	"ray_tracer_go_v2/calc"
)

// Color is an alias for calc.Vec3.
type Color = calc.Vec3
